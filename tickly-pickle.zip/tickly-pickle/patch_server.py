import os
import pickle
import hmac
import hashlib

def reverse_fun():
    with open("users.json","rb") as f:
        data = f.read()
      
    try:
          safecode,orig_digest = data.split(bytes('~','utf-8'))
    except ValueError:
            return "users.json digest not found"

    new_digest = hmac.new(bytes('SaFeKeY','utf-8'),safecode,hashlib.sha1).hexdigest()

    if hmac.compare_digest(orig_digest,bytes(new_digest,'utf-8')):
          d = pickle.loads(safecode)
          return d
    else:
          return "payload modified hacking detected!!!"

if __name__ == '__main__':
      print(reverse_fun())